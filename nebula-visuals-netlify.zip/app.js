// Nebula Visuals — Static site logic (Netlify ready)
// Video background, particles, scroll reveal, comparison slider, FAQ, auth/profile modal, profile dropdown

(function () {
  'use strict';

  // ===== STATE MANAGEMENT =====
  const AuthState = {
    user: null,
    
    init() {
      const saved = localStorage.getItem('nebula_auth');
      if (saved) {
        try {
          this.user = JSON.parse(saved);
          this.updateUI();
        } catch (e) {
          localStorage.removeItem('nebula_auth');
        }
      }
      this.bindTabs();
    },
    
    save() {
      localStorage.setItem('nebula_auth', JSON.stringify(this.user));
    },
    
    login(username, email, remember = true) {
      this.user = { username, email, ram: 4096, avatar: '', joined: new Date().toISOString() };
      if (remember) this.save();
      this.updateUI();
      return true;
    },
    
    register(username, email, password) {
      this.user = { username, email, ram: 4096, avatar: '', joined: new Date().toISOString() };
      this.save();
      this.updateUI();
      return true;
    },
    
    logout() {
      this.user = null;
      localStorage.removeItem('nebula_auth');
      this.updateUI();
    },
    
    updateUI() {
      const navAuthBtn = document.getElementById('nav-auth-btn');
      const navProfile = document.getElementById('nav-profile');
      const navProfileAvatar = document.getElementById('nav-profile-avatar');
      const navProfileName = document.getElementById('nav-profile-name');
      const dropdownAvatar = document.getElementById('dropdown-avatar');
      const dropdownName = document.getElementById('dropdown-name');
      const dropdownEmail = document.getElementById('dropdown-email');
      const dropdownRam = document.getElementById('dropdown-ram');
      const dropdownServer = document.getElementById('dropdown-server');
      const dropdownAvatar2 = document.getElementById('dropdown-avatar');
      
      if (this.user) {
        // Show profile, hide auth button
        document.getElementById('nav-auth-btn').style.display = 'none';
        document.getElementById('nav-profile').style.display = 'flex';
        
        // Update nav profile
        if (navProfileAvatar) navProfileAvatar.textContent = this.user.username.charAt(0).toUpperCase();
        if (navProfileName) navProfileName.textContent = this.user.username;
        
        // Update dropdown
        if (dropdownAvatar) dropdownAvatar.textContent = this.user.username.charAt(0).toUpperCase();
        if (dropdownName) dropdownName.textContent = this.user.username;
        if (dropdownEmail) dropdownEmail.textContent = this.user.email;
        if (dropdownRam) dropdownRam.textContent = (this.user.ram || 4096) + ' MB';
        if (dropdownServer) dropdownServer.textContent = 'Подключен';
      } else {
        // Show auth button, hide profile
        document.getElementById('nav-auth-btn').style.display = 'flex';
        document.getElementById('nav-profile').style.display = 'none';
      }
    },
    
    bindTabs() {
      // Modal tabs
      document.querySelectorAll('.modal-switch-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const target = btn.id === 'switch-to-register' ? 'register' : 'login';
          this.switchAuthTab(target);
        });
      });
    },
    
    switchAuthTab(target) {
      const loginTab = document.getElementById('auth-login-tab');
      const registerTab = document.getElementById('auth-register-tab');
      
      if (target === 'register') {
        loginTab.hidden = true;
        registerTab.hidden = false;
      } else {
        registerTab.hidden = true;
        loginTab.hidden = false;
      }
    },
    
    save() {
      localStorage.setItem('nebula_auth', JSON.stringify(this.user));
    },
    
    login(username, email, remember = true) {
      this.user = { username, email, ram: 4096, avatar: '', joined: new Date().toISOString() };
      if (remember) this.save();
      this.updateUI();
      return true;
    },
    
    register(username, email, password) {
      this.user = { username, email, ram: 4096, avatar: '', joined: new Date().toISOString() };
      this.save();
      this.updateUI();
      return true;
    },
    
    logout() {
      this.user = null;
      localStorage.removeItem('nebula_auth');
      this.updateUI();
    },
    
    updateUI() {
      const navAuthBtn = document.getElementById('nav-auth-btn');
      const navProfile = document.getElementById('nav-profile');
      const navProfileAvatar = document.getElementById('nav-profile-avatar');
      const navProfileName = document.getElementById('nav-profile-name');
      const dropdownAvatar = document.getElementById('dropdown-avatar');
      const dropdownName = document.getElementById('dropdown-name');
      const dropdownEmail = document.getElementById('dropdown-email');
      const dropdownRam = document.getElementById('dropdown-ram');
      const dropdownServer = document.getElementById('dropdown-server');
      
      if (this.user) {
        // Show profile, hide auth button
        const navAuthBtn = document.getElementById('nav-auth-btn');
        const navProfile = document.getElementById('nav-profile');
        if (navAuthBtn) navAuthBtn.style.display = 'none';
        if (navProfile) navProfile.style.display = 'flex';
        
        // Update nav profile
        const navProfileAvatar = document.getElementById('nav-profile-avatar');
        const navProfileName = document.getElementById('nav-profile-name');
        if (navProfileAvatar) navProfileAvatar.textContent = this.user.username.charAt(0).toUpperCase();
        if (navProfileName) navProfileName.textContent = this.user.username;
        
        // Update dropdown
        const dropdownAvatar = document.getElementById('dropdown-avatar');
        const dropdownName = document.getElementById('dropdown-name');
        const dropdownEmail = document.getElementById('dropdown-email');
        const dropdownRam = document.getElementById('dropdown-ram');
        const dropdownServer = document.getElementById('dropdown-server');
        
        if (dropdownAvatar) dropdownAvatar.textContent = this.user.username.charAt(0).toUpperCase();
        if (dropdownName) dropdownName.textContent = this.user.username;
        if (dropdownEmail) dropdownEmail.textContent = this.user.email;
        if (dropdownRam) dropdownRam.textContent = (this.user.ram || 4096) + ' MB';
        if (dropdownServer) dropdownServer.textContent = 'Подключен';
      } else {
        // Show auth button, hide profile
        const navAuthBtn = document.getElementById('nav-auth-btn');
        const navProfile = document.getElementById('nav-profile');
        if (navAuthBtn) navAuthBtn.style.display = 'flex';
        if (navProfile) navProfile.style.display = 'none';
      }
    },
  };

  // ===== VIDEO BACKGROUND (FIXED - NO PARALLAX) =====
  const bgVideo = document.getElementById('bg-video');
  if (bgVideo) {
    bgVideo.muted = true;
    bgVideo.playsInline = true;
    bgVideo.play().catch(() => { bgVideo.style.display = 'none'; });
  }

  // ===== PARTICLES =====
  const canvas = document.getElementById('particles');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    let particles = [];
    let w = 0, h = 0, dpr = window.devicePixelRatio || 1;
    function resize() { w = canvas.width = window.innerWidth * dpr; h = canvas.height = window.innerHeight * dpr; canvas.style.width = window.innerWidth + 'px'; canvas.style.height = window.innerHeight + 'px'; }
    window.addEventListener('resize', resize); resize();
    class Particle { constructor() { this.reset(); } reset() { this.x = Math.random() * w; this.y = Math.random() * h; this.r = Math.random() * 1.5 + 0.5; this.vx = (Math.random() - 0.5) * 0.3; this.vy = (Math.random() - 0.5) * 0.3; this.alpha = Math.random() * 0.4 + 0.1; this.color = Math.random() > 0.5 ? '#4a9eff' : '#a86bff'; } step() { this.x += this.vx; this.y += this.vy; if (this.x < -10 || this.x > w + 10 || this.y < -10 || this.y > h + 10) this.reset(); } draw() { ctx.beginPath(); ctx.arc(this.x, this.y, this.r * dpr, 0, Math.PI * 2); ctx.fillStyle = this.color; ctx.globalAlpha = this.alpha; ctx.fill(); ctx.globalAlpha = 1; } }
    for (let i = 0; i < 50; i++) particles.push(new Particle());
    function animate() { ctx.clearRect(0, 0, w, h); particles.forEach(p => { p.step(); p.draw(); }); for (let i = 0; i < particles.length; i++) { for (let j = i + 1; j < particles.length; j++) { const dx = particles[i].x - particles[j].x; const dy = particles[i].y - particles[j].y; const dist = Math.sqrt(dx * dx + dy * dy); if (dist < 120 * dpr) { ctx.beginPath(); ctx.moveTo(particles[i].x, particles[i].y); ctx.lineTo(particles[j].x, particles[j].y); ctx.strokeStyle = 'rgba(74,158,255,' + (0.06 * (1 - dist / (120 * dpr))) + ')'; ctx.lineWidth = 0.5 * dpr; ctx.stroke(); } } } requestAnimationFrame(animate); } animate();
  }

  // ===== SCROLL REVEAL =====
  const revealEls = document.querySelectorAll('.section-header, .card, .stat, .faq details, .server-card, .screen-card, .hero-title, .hero-sub, .hero-buttons, .hero-stats, .server-grid, .server-connect, .video-wrapper, .register-form');
  const observer = new IntersectionObserver((entries) => { entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); if (e.target.parentElement && e.target.parentElement.classList.contains('cards')) { const sibs = Array.from(e.target.parentElement.children); e.target.style.transitionDelay = (sibs.indexOf(e.target) * 0.1) + 's'; } if (e.target.parentElement && e.target.parentElement.classList.contains('server-grid')) { const sibs = Array.from(e.target.parentElement.children); e.target.style.transitionDelay = (sibs.indexOf(e.target) * 0.1) + 's'; } if (e.target.parentElement && e.target.parentElement.classList.contains('hero-stats')) { const sibs = Array.from(e.target.parentElement.children); e.target.style.transitionDelay = (sibs.indexOf(e.target) * 0.15) + 's'; } } }); }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });
  revealEls.forEach(el => { el.classList.add('reveal'); observer.observe(el); });

  // ===== NAV SCROLL STATE =====
  const nav = document.getElementById('nav');
  window.addEventListener('scroll', () => { if (window.scrollY > 20) nav.classList.add('scrolled'); else nav.classList.remove('scrolled'); }, { passive: true });

  // ===== SMOOTH SCROLL =====
  document.querySelectorAll('a[href^="#"]').forEach(a => { a.addEventListener('click', e => { const id = a.getAttribute('href'); if (id === '#') return; const t = document.querySelector(id); if (t) { e.preventDefault(); t.scrollIntoView({ behavior: 'smooth', block: 'start' }); } }); });

  // ===== FEATURES =====
  const features = [
    { icon: '✦', title: 'Визуальные модули', desc: 'Подсветка игроков, информация о здоровье, координаты, таймеры и десятки настроек — всё в одном профиле.' },
    { icon: '⚡', title: 'Оптимизация FPS', desc: 'Отсечение дальних сущностей, частиц и блок-энтити. Больше FPS на слабых ПК без потери картинки.' },
    { icon: '↓', title: 'Автоустановка', desc: 'Лаунчер сам скачивает библиотеки, ресурсы и Java. Уже установленные файлы заново не качаются.' },
    { icon: '↻', title: 'Умные обновления', desc: 'Когда выходит новая версия — лаунчер покажет сообщение и обновит только изменившийся мод.' },
    { icon: '☰', title: 'Профиль игрока', desc: 'Ник, выделенная память и аватар сохраняются и подтягиваются при каждом запуске.' },
    { icon: '🔒', title: 'Оффлайн-режим', desc: 'Работает без лицензии, оффлайн-UUID, свой ник — просто запускай и играй.' }
  ];
  const cardsContainer = document.getElementById('features-cards');
  if (cardsContainer) cardsContainer.innerHTML = features.map((f, i) => `<article class="card" style="animation-delay: ${i * 0.1}s;"><div class="card-icon">${f.icon}</div><h3>${f.title}</h3><p>${f.desc}</p></article>`).join('');

  // ===== FAQ =====
  const faqs = [
    { q: 'Куда устанавливается игра?', a: 'Файлы игры складываются в <code>C:\\NebulaVisuals\\game\\1.21.4</code>. Лаунчер устанавливается в вашу пользовательскую папку программ.' },
    { q: 'Почему нужны права администратора?', a: 'Чтобы создать папку игры в корне диска <code>C:</code> и корректно прописать ярлыки и систему обновления.' },
    { q: 'Файлы скачиваются заново каждый запуск?', a: 'Нет. Лаунчер проверяет установленные файлы и запускает игру сразу. Скачивается только то, чего не хватает, либо обновившийся мод.' },
    { q: 'Это официальный клиент?', a: 'Нет, Nebula Visuals — неофициальный клиент для лицензионной и пиратской игры в оффлайн-режиме. Не связан с Mojang и Microsoft.' },
    { q: 'Какая версия Minecraft?', a: '1.21.4 на Fabric. Лаунчер сам тянет нужные библиотеки и моды.' },
    { q: 'Как обновить клиент?', a: 'При выходе обновления лаунчер покажет уведомление. Нажми «Запустить» — он сам скачает новый мод и заменит старый.' },
    { q: 'Есть ли сервер в моде?', a: 'Да! В моде есть встроенный сервер: поиск игроков, чат, друзья, голосовой чат, уведомления — всё работает внутри клиента.' },
    { q: 'Откуда скачивается лаунчер?', a: 'С Google Drive — прямая ссылка, без ожиданий и рекламы. Файл ~77 MB.' }
  ];
  const faqList = document.getElementById('faq-list');
  if (faqList) {
    faqList.innerHTML = faqs.map((f, i) => `<details style="animation-delay: ${i * 0.05}s;"><summary>${f.q}</summary><div class="faq-answer">${f.a}</div></details>`).join('');
    const details = faqList.querySelectorAll('details');
    details.forEach(d => { const s = d.querySelector('summary'); const a = d.querySelector('.faq-answer'); if (!a) return; a.style.maxHeight = '0'; a.style.opacity = '0'; a.style.overflow = 'hidden'; a.style.transition = 'max-height 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94), opacity 0.3s ease'; function open() { a.style.maxHeight = a.scrollHeight + 'px'; a.style.opacity = '1'; } function close() { a.style.maxHeight = '0'; a.style.opacity = '0'; } d.addEventListener('toggle', () => { if (d.open) open(); else close(); }); s.addEventListener('click', () => { if (!d.open) details.forEach(o => { if (o !== d && o.open) o.open = false; }); }); });
  }

  // ===== AUTH MODAL =====
  const modal = document.getElementById('auth-modal');
  const navAuthBtn = document.getElementById('nav-auth-btn');
  const modalClose = document.getElementById('auth-modal-close');
  const switchToReg = document.getElementById('switch-to-register');
  const switchToLogin = document.getElementById('switch-to-login');
  const loginTab = document.getElementById('auth-login-tab');
  const registerTab = document.getElementById('auth-register-tab');
  const loginForm = document.getElementById('login-form');
  const registerForm = document.getElementById('register-form');

  function openAuthModal(tab = 'login') {
    modal.hidden = false;
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
    switchAuthTab(tab);
  }
  function closeAuthModal() {
    modal.hidden = true;
    modal.style.display = 'none';
    document.body.style.overflow = '';
    clearErrors();
  }
  function switchAuthTab(target) {
    const loginTab = document.getElementById('auth-login-tab');
    const registerTab = document.getElementById('auth-register-tab');
    if (target === 'register') { loginTab.hidden = true; registerTab.hidden = false; }
    else { registerTab.hidden = true; loginTab.hidden = false; }
    clearErrors();
  }
  function clearErrors() {
    document.querySelectorAll('.form-error, .form-ok').forEach(el => el.textContent = '');
  }

  if (navAuthBtn) navAuthBtn.addEventListener('click', () => openAuthModal('login'));
  if (modalClose) modalClose.addEventListener('click', closeAuthModal);
  if (switchToReg) switchToReg.addEventListener('click', () => switchAuthTab('register'));
  if (switchToLogin) switchToLogin.addEventListener('click', () => switchAuthTab('login'));
  if (modal) modal.addEventListener('click', e => { if (e.target === modal) closeAuthModal(); });

  // Login form
  if (loginForm) loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('modal-login-submit');
    const err = document.getElementById('modal-auth-error');
    const ok = document.getElementById('modal-auth-ok');
    clearErrors();
    const username = document.getElementById('modal-login-username').value.trim();
    const password = document.getElementById('modal-login-password').value;
    if (!username || !password) { if (err) err.textContent = 'Введите ник/email и пароль'; return; }
    btn.disabled = true; btn.textContent = 'Вход...';
    await new Promise(r => setTimeout(r, 800));
    const isEmail = username.includes('@');
    const email = isEmail ? username.toLowerCase() : username.toLowerCase() + '@nebula.local';
    const uname = isEmail ? username.split('@')[0] : username;
    AuthState.login(uname, email, document.getElementById('modal-remember').checked);
    if (ok) ok.textContent = 'Вход выполнен!';
    btn.disabled = false; btn.textContent = 'Войти';
    document.getElementById('modal-login-username').value = '';
    document.getElementById('modal-login-password').value = '';
    setTimeout(closeAuthModal, 800);
    AuthState.updateUI();
  });

  // Register form
  const registerFormEl = document.getElementById('register-form');
  if (registerFormEl) registerFormEl.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('modal-register-submit');
    const err = document.getElementById('modal-register-error');
    const ok = document.getElementById('modal-register-ok');
    clearErrors();
    const username = document.getElementById('modal-reg-username').value.trim();
    const email = document.getElementById('modal-reg-email').value.trim().toLowerCase();
    const password = document.getElementById('modal-reg-password').value;
    const confirm = document.getElementById('modal-reg-password-confirm').value;
    if (!username || !email || !password || !confirm) { if (err) err.textContent = 'Заполните все поля'; return; }
    if (username.length < 3 || username.length > 16) { if (err) err.textContent = 'Ник: 3–16 символов'; return; }
    if (!/^[A-Za-z0-9_]+$/.test(username)) { if (err) err.textContent = 'Ник: только латиница, цифры и _'; return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { if (err) err.textContent = 'Некорректный email'; return; }
    if (password.length < 6) { if (err) err.textContent = 'Пароль минимум 6 символов'; return; }
    if (password !== confirm) { if (err) err.textContent = 'Пароли не совпадают'; return; }
    btn.disabled = true; btn.textContent = 'Регистрация...';
    await new Promise(r => setTimeout(r, 800));
    AuthState.register(username, email, password);
    if (ok) ok.textContent = 'Регистрация успешна!';
    btn.disabled = false; btn.textContent = 'Зарегистрироваться';
    document.getElementById('modal-reg-username').value = '';
    document.getElementById('modal-reg-email').value = '';
    document.getElementById('modal-reg-password').value = '';
    document.getElementById('modal-reg-password-confirm').value = '';
    setTimeout(() => { switchAuthTab('login'); closeAuthModal(); AuthState.updateUI(); }, 800);
  });

  // ===== PROFILE DROPDOWN =====
  const navProfileBtn = document.getElementById('nav-profile-btn');
  const navProfileDropdown = document.getElementById('nav-profile-dropdown');
  const dropdownDownload = document.getElementById('dropdown-download');
  const dropdownLogout = document.getElementById('dropdown-logout');

  if (navProfileBtn) navProfileBtn.addEventListener('click', e => { e.stopPropagation(); navProfileDropdown.classList.toggle('open'); });
  document.addEventListener('click', e => { if (navProfileDropdown && !navProfileDropdown.contains(e.target) && e.target !== navProfileBtn) navProfileDropdown.classList.remove('open'); });

  if (dropdownDownload) dropdownDownload.addEventListener('click', () => {
    window.open('https://drive.google.com/uc?export=download&id=1vV0IfVQDqHPpjdM_6LInXzrdtpCXWat_', '_blank');
    navProfileDropdown.classList.remove('open');
  });
  if (dropdownLogout) dropdownLogout.addEventListener('click', () => {
    AuthState.logout();
    toast('Вы вышли из аккаунта');
    navProfileDropdown.classList.remove('open');
  });

  // ===== DOWNLOAD BUTTON IN HERO =====
  const heroDownload = document.getElementById('hero-download');
  if (heroDownload) heroDownload.addEventListener('click', e => { e.preventDefault(); window.open('https://drive.google.com/uc?export=download&id=1vV0IfVQDqHPpjdM_6LInXzrdtpCXWat_', '_blank'); });

  // ===== FILE DOWNLOAD IN VIDEO SECTION =====
  const fileDownloadBtn = document.getElementById('dropdown-download'); // also in dropdown
  const fileDownloadBtn2 = document.querySelector('.file-download .btn');
  if (fileDownloadBtn2) fileDownloadBtn2.addEventListener('click', e => { e.preventDefault(); window.open('/files/launcher-files.zip', '_blank'); });

  // ===== FAQ =====
  const faqs = [
    { q: 'Куда устанавливается игра?', a: 'Файлы игры складываются в <code>C:\\NebulaVisuals\\game\\1.21.4</code>. Лаунчер устанавливается в вашу пользовательскую папку программ.' },
    { q: 'Почему нужны права администратора?', a: 'Чтобы создать папку игры в корне диска <code>C:</code> и корректно прописать ярлыки и систему обновления.' },
    { q: 'Файлы скачиваются заново каждый запуск?', a: 'Нет. Лаунчер проверяет установленные файлы и запускает игру сразу. Скачивается только то, чего не хватает, либо обновившийся мод.' },
    { q: 'Это официальный клиент?', a: 'Нет, Nebula Visuals — неофициальный клиент для лицензионной и пиратской игры в оффлайн-режиме. Не связан с Mojang и Microsoft.' },
    { q: 'Какая версия Minecraft?', a: '1.21.4 на Fabric. Лаунчер сам тянет нужные библиотеки и моды.' },
    { q: 'Как обновить клиент?', a: 'При выходе обновления лаунчер покажет уведомление. Нажми «Запустить» — он сам скачает новый мод и заменит старый.' },
    { q: 'Есть ли сервер в моде?', a: 'Да! В моде есть встроенный сервер: поиск игроков, чат, друзья, голосовой чат, уведомления — всё работает внутри клиента.' },
    { q: 'Откуда скачивается лаунчер?', a: 'С Google Drive — прямая ссылка, без ожиданий и рекламы. Файл ~77 MB.' }
  ];
  const faqList = document.getElementById('faq-list');
  if (faqList) {
    faqList.innerHTML = faqs.map((f, i) => `<details style="animation-delay: ${i * 0.05}s;"><summary>${f.q}</summary><div class="faq-answer">${f.a}</div></details>`).join('');
    const details = faqList.querySelectorAll('details');
    details.forEach(d => { const s = d.querySelector('summary'); const a = d.querySelector('.faq-answer'); if (!a) return; a.style.maxHeight = '0'; a.style.opacity = '0'; a.style.overflow = 'hidden'; a.style.transition = 'max-height 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94), opacity 0.3s ease'; function open() { a.style.maxHeight = a.scrollHeight + 'px'; a.style.opacity = '1'; } function close() { a.style.maxHeight = '0'; a.style.opacity = '0'; } d.addEventListener('toggle', () => { if (d.open) open(); else close(); }); s.addEventListener('click', () => { if (!d.open) details.forEach(o => { if (o !== d && o.open) o.open = false; }); }); });
  }

  // ===== COMPARISON SLIDER =====
  const slider = document.getElementById('comparison-slider');
  const sliderBefore = slider?.querySelector('.slider-before');
  const sliderHandle = document.getElementById('slider-handle');
  const sliderHitArea = document.querySelector('.slider-hit-area');
  
  if (slider && sliderBefore && sliderHandle && sliderHitArea) {
    let isDragging = false;

    function updateSlider(clientX) {
      const rect = slider.getBoundingClientRect();
      let percent = ((clientX - rect.left) / rect.width) * 100;
      percent = Math.max(0, Math.min(100, percent));
      
      sliderBefore.style.clipPath = `polygon(0 0, ${percent}% 0, ${percent}% 100%, 0 100%)`;
      sliderHandle.style.left = `${percent}%`;
      sliderHandle.setAttribute('aria-valuenow', Math.round(percent));
    }

    function onPointerDown(e) {
      isDragging = true;
      sliderHandle.style.transition = 'none';
      document.body.style.userSelect = 'none';
    }

    function onPointerMove(e) {
      if (!isDragging) return;
      const clientX = e.touches ? e.touches[0].clientX : e.clientX;
      updateSlider(clientX);
    }

    function onPointerUp() {
      isDragging = false;
      sliderHandle.style.transition = 'left 0.1s ease';
      document.body.style.userSelect = '';
    }

    // Mouse/Touch events on HIT AREA (large invisible area)
    if (sliderHitArea) {
      sliderHitArea.addEventListener('mousedown', (e) => {
        isDragging = true;
        sliderHandle.style.transition = 'none';
        document.body.style.userSelect = 'none';
      });
      sliderHitArea.addEventListener('touchstart', (e) => {
        isDragging = true;
        sliderHandle.style.transition = 'none';
        document.body.style.userSelect = 'none';
      }, { passive: true });
    }
    
    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      updateSlider(e.clientX);
    });
    document.addEventListener('touchmove', (e) => {
      if (!isDragging) return;
      updateSlider(e.touches[0].clientX);
    }, { passive: true });
    document.addEventListener('mouseup', () => {
      isDragging = false;
      sliderHandle.style.transition = 'left 0.1s ease';
      document.body.style.userSelect = '';
    });
    document.addEventListener('touchend', () => {
      isDragging = false;
      sliderHandle.style.transition = 'left 0.1s ease';
      document.body.style.userSelect = '';
    });

    // Click on slider track to jump
    const sliderEl = document.getElementById('comparison-slider');
    if (sliderEl) {
      sliderEl.addEventListener('click', (e) => {
        if (e.target.closest('.slider-handle')) return;
        updateSlider(e.clientX);
      });
    }

    // Keyboard support
    sliderHandle.addEventListener('keydown', (e) => {
      const step = e.shiftKey ? 10 : 5;
      let percent = parseInt(sliderHandle.style.left) || 50;
      if (e.key === 'ArrowLeft') percent = Math.max(0, percent - step);
      else if (e.key === 'ArrowRight') percent = Math.min(100, percent + step);
      else return;
      e.preventDefault();
      const sliderBefore = document.querySelector('.slider-before');
      if (sliderBefore) {
        sliderBefore.style.clipPath = `polygon(0 0, ${percent}% 0, ${percent}% 100%, 0 100%)`;
      }
      sliderHandle.style.left = `${percent}%`;
      sliderHandle.setAttribute('aria-valuenow', percent);
    });
  }

  // ===== TOAST =====
  window.toast = function(msg, success) { const el = document.getElementById('toast'); if (!el) return; el.textContent = msg; el.hidden = false; el.classList.toggle('toast-success', success); setTimeout(() => { el.hidden = true; el.classList.remove('toast-success'); }, 2600); };

  // ===== YEAR =====
  const yearEl = document.getElementById('year'); if (yearEl) yearEl.textContent = new Date().getFullYear();

  // ===== INIT =====
  AuthState.init();

  // ===== SCREENSHOTS ZOOM =====
  document.querySelectorAll('.screen-frame img').forEach(img => { img.style.cursor = 'zoom-in'; img.addEventListener('click', () => { const o = document.createElement('div'); o.style.cssText = 'position:fixed;inset:0;z-index:1000;background:rgba(0,0,0,0.95);display:flex;align-items:center;justify-content:center;animation:fadeIn .2s ease'; const i = document.createElement('img'); i.src = img.src; i.alt = img.alt; i.style.cssText = 'max-width:90vw;max-height:90vh;object-fit:contain'; o.appendChild(i); o.addEventListener('click', () => o.remove()); document.body.appendChild(o); }); });

})();